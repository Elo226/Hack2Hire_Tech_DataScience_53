from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

# Chargement du modèle
model = joblib.load("credit_risk_model.pkl")
# Création de l'instance FastAPI
app = FastAPI()


# Classe Pydantic pour valider les données d'entrée
class CreditRequest(BaseModel):
    Sex: str
    Job: str
    Housing: str
    Saving_accounts: str
    Checking_account: str
    Credit_amount: int
    Duration: int
    Purpose: str
    Age: int


# Encodage des variables catégoriques
def encode_age(age):
    if age < 25:
        return 1  # Jeune
    elif 25 <= age < 40:
        return 0  # Adulte
    elif 40 <= age < 60:
        return 2  # Mature
    else:
        return 3  # Senior


def encode_data(data):
    # Dictionnaires pour mapper les valeurs catégoriques
    sex_mapping = {"feminin": 0, "masculin": 1}
    job_mapping = {" non qualifié et non-résident": 0, "non qualifié et résident": 1, "hautement qualifié": 3, " qualifié": 2}
    housing_mapping = {"proprietaire": 1, "gratuit": 0, "locataire": 2}
    saving_mapping = {"petit": 0, "modéré": 1, "riche": 3, "assez riche": 2}
    checking_mapping = {"petit": 0, "modéré": 1, "riche": 2}
    purpose_mapping = {
        "radio/TV": 5,
        "education": 3,
        "mobilier/équipement": 4,
        "voiture": 1,
        "business": 0,
        "appareils électroménagers": 2,
        "reparations": 6,
        "vacances/autres": 7,
    }


    # Encodage des données
    data["Sex"] = sex_mapping[data["Sex"]]
    data["Job"] = job_mapping[data["Job"]]
    data["Housing"] = housing_mapping[data["Housing"]]
    data["Saving_accounts"] = saving_mapping[data["Saving_accounts"]]
    data["Checking_account"] = checking_mapping[data["Checking_account"]]
    data["Purpose"] = purpose_mapping[data["Purpose"]]
    data["Age"] = encode_age(data["Age"])

    return data


# Route pour prédire le risque de crédit

# Point de test (racine)
@app.get("/")
def read_root():
    return {"message": "Bienvenue sur mon API avec FastAPI !"}



@app.post("/predict")
def predict_credit_risk(request: CreditRequest):
    # Convertir les données en dictionnaire et encoder
    raw_data = request.dict()
    encoded_data = encode_data(raw_data)

    # Préparer les données pour le modèle
    input_data = np.array(
        [
            [
                encoded_data["Sex"],
                encoded_data["Job"],
                encoded_data["Housing"],
                encoded_data["Saving_accounts"],
                encoded_data["Checking_account"],
                encoded_data["Credit_amount"],
                encoded_data["Duration"],
                encoded_data["Purpose"],
                encoded_data["Age"],
            ]
        ]
    )


    # Faire une prédiction
    prediction = model.predict(input_data)

    # Retourner le risque en format JSON
    return {"Risk": "Mauvais" if prediction[0] == 1 else "Bon"}

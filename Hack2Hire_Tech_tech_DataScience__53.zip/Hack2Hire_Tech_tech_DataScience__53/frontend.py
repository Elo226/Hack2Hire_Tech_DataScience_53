import streamlit as st
import requests

# URL de l'API FastAPI
api_url = "http://127.0.0.1:8000/predict"

# Interface Streamlit
st.title("Prédiction du Risque de Crédit")

# Inputs
sex = st.selectbox("Sexe", ["feminin", "masculin"])
job = st.selectbox("Emploi", [" non qualifié et non-résident", "non qualifié et résident"," qualifié","hautement qualifié"])
housing = st.selectbox("Logement", ["proprietaire", "gratuit", "locataire"])
saving_accounts = st.selectbox("Comptes d'épargne", ["petit", "modéré", "riche", "assez riche"])
checking_account = st.selectbox("Compte courant", ["petit", "modéré", "riche"])
credit_amount = st.number_input("Montant du crédit", min_value=0)
duration = st.number_input("Durée (mois)", min_value=0)
purpose = st.selectbox("But du crédit", ["radio/TV", "education", "mobilier/équipement", "voiture", "business", "appareils électroménagers", "reparations", "vacances/autres"])
age = st.number_input("Âge", min_value=0)

# Préparer les données d'entrée
if st.button("Prédire"):
    input_data = {
        "Sex": sex,
        "Job": job,
        "Housing": housing,
        "Saving_accounts": saving_accounts,
        "Checking_account": checking_account,
        "Credit_amount": credit_amount,
        "Duration": duration,
        "Purpose": purpose,
        "Age": age,
    }
    
    # Faire la requête POST vers l'API FastAPI
    response = requests.post(api_url, json=input_data)

    if response.status_code == 200:
        result = response.json()["Risk"]
        if result == "Bon":
            st.success("Risque de crédit: Bon", icon="✅")
        else:
            st.error("Risque de crédit: Mauvais", icon="❌")

    else:
        st.write(f"Erreur lors de la prédiction: {response.status_code}")
    
